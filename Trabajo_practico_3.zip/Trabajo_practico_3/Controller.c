#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include "LinkedList.h"
#include "Employee.h"
#include "parser.h"
#include "validaciones.h"
#include "Controller.h"

int sortEmployee(void* emp1, void* emp2);

/** \brief Carga los datos de los empleados desde el archivo data.csv (modo texto).
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int Retorna la cantidad de empleados cargados
 *
 */
int controller_loadFromText(char* path , LinkedList* pArrayListEmployee)
{
    int contador = 0;
    FILE* file = NULL;

    if(pArrayListEmployee != NULL && path != NULL)
    {
        file = fopen(path, "r");

        if(file != NULL)
        {
            contador = parser_EmployeeFromText(file, pArrayListEmployee);
        }
    }

    fclose(file);

    return contador;
}

/** \brief Carga los datos de los empleados desde el archivo data.csv (modo binario).
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int Retorna la cantidad de empleados cargados
 *
 */
int controller_loadFromBinary(char* path , LinkedList* pArrayListEmployee)
{
    int contador = 0;
    FILE* file = NULL;

    if(pArrayListEmployee != NULL && path != NULL)
    {
        file = fopen(path, "rb");

        if(file != NULL)
        {
            contador = parser_EmployeeFromBinary(file, pArrayListEmployee);

        }
    }

    fclose(file);

    return contador;
}

/** \brief Alta de empleados
 *
 * \param pArrayListEmployee LinkedList*
 * \return int Retorna 1 si se pudo agregar un empleado
 *
 */
int controller_addEmployee(LinkedList* pArrayListEmployee, int* cantidadEmpleadosP)
{
    int todoOk = 0;
    eEmployee* nuevoEmpleado = NULL;
    char nombre[128];
    char idStr[10];
    char horasTrabajadasStr[10];
    char sueldoStr[10];

    int largoArray = ll_len(pArrayListEmployee);

    if(largoArray >= 2000)
    {
        printf("\nNo hay mas espacio para cargar empleados.\n");
    }
    else if(largoArray == 0)
    {
        printf("\nPrimero debe cargar los empleados del archivo.\n");
    }
    else
    {
        sprintf(idStr, "%d", (*cantidadEmpleadosP)+1);

        printf("\nIngrese el nombre: ");
        fflush(stdin);
        gets(nombre);
        while(!esSoloLetras(nombre))
        {
            printf("Error. Ingrese el nombre: ");
            fflush(stdin);
            gets(nombre);
        }

        printf("\nIngrese las horas trabajadas: ");
        fflush(stdin);
        scanf("%s", horasTrabajadasStr);
        while(!esNumerico(horasTrabajadasStr) || atoi(horasTrabajadasStr) > 1000)
        {
            printf("Error. Ingrese las horas trabajadas: ");
            fflush(stdin);
            scanf("%s", horasTrabajadasStr);
        }

        printf("\nIngrese el sueldo: ");
        fflush(stdin);
        scanf("%s", sueldoStr);
        while(!esNumericoFlotante(sueldoStr) || atof(sueldoStr) > 1000000)
        {
            printf("Error. Ingrese el sueldo: ");
            fflush(stdin);
            scanf("%s", sueldoStr);
        }
    }

    nuevoEmpleado = employee_newParametros(idStr, nombre, horasTrabajadasStr, sueldoStr);

    if(nuevoEmpleado != NULL)
    {
        if(ll_add(pArrayListEmployee, (eEmployee*) nuevoEmpleado) == 0)
        {
            system("cls");
            printf("\nSe cargo con exito el nuevo empleado!\n\n");
            todoOk = 1;
        }
    }

    return todoOk;
}

/** \brief Modificar datos de empleado
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int Retorna 1 si se pudo editar el empleado
 *
 */
int controller_editEmployee(LinkedList* pArrayListEmployee)
{
    int todoOk = 0;
    int flag = 0;
    int opcion;
    char salir = 'n';
    char idStr[10];
    char nombre[128];
    char horasTrabajadasStr[10];
    char sueldoStr[10];
    int largoArray = 0;
    eEmployee* auxEmpleado = NULL;

    if(pArrayListEmployee != NULL)
    {
        largoArray = ll_len(pArrayListEmployee);

        if(controller_ListEmployee(pArrayListEmployee) == 0)
        {
            printf("No hay empleados por editar.\n");
        }
        else
        {
            do
            {
                printf("\nIngrese el id del empleado a modificar: ");
                fflush(stdin);
                scanf("%s", idStr);
                while(!esNumerico(idStr))
                {
                    printf("Error. Ingrese un id valido: ");
                    fflush(stdin);
                    scanf("%s", idStr);
                }
                for(int i=0; i < largoArray; i++)
                {
                    auxEmpleado = (eEmployee*) ll_get(pArrayListEmployee, i);
                    if(auxEmpleado->id == atoi(idStr))
                    {
                        flag = 1;
                        break;
                    }
                }
                if(!flag)
                {
                    printf("Error. No existe empleado con ese id\n");
                }

            }while(flag == 0);

            if(auxEmpleado != NULL)
            {
                do
                {
                    system("cls");

                    printf("***** Modificar empleado *****\n\n");

                    printf("\n|   Id   |       Nombre       |  Horas trabajadas |  Sueldo    |\n");
                    printf("----------------------------------------------------------------\n");
                    printf("| %4d   |  %15s   |        %4d       |   %4.2f |\n", auxEmpleado->id, auxEmpleado->nombre, auxEmpleado->horasTrabajadas, auxEmpleado->sueldo);

                    printf("\n1- Modificar nombre\n");
                    printf("2- Modificar horas tranajadas\n");
                    printf("3- Modificar sueldo\n");
                    printf("4- Salir\n\n");
                    printf("Ingrese opcion: ");
                    scanf("%d", &opcion);
                    while(opcion < 1 || opcion > 4)
                    {
                        printf("Error. Ingrese una opcion valida: ");
                        scanf("%d", &opcion);
                    }

                    switch(opcion)
                    {
                        case 1:
                            printf("\nIngrese el nombre: ");
                            fflush(stdin);
                            gets(nombre);
                            while(!esSoloLetras(nombre))
                            {
                                printf("Error. Ingrese el nombre: ");
                                fflush(stdin);
                                gets(nombre);
                            }
                            strcpy(auxEmpleado->nombre, nombre);
                            todoOk = 1;
                            break;

                        case 2:
                            printf("\nIngrese las horas trabajadas: ");
                            fflush(stdin);
                            scanf("%s", horasTrabajadasStr);
                            while(!esNumerico(horasTrabajadasStr) || atoi(horasTrabajadasStr) > 1000)
                            {
                                printf("Error. Ingrese las horas trabajadas: ");
                                fflush(stdin);
                                scanf("%s", horasTrabajadasStr);
                            }
                            auxEmpleado->horasTrabajadas = atoi(horasTrabajadasStr);
                            todoOk = 1;
                            break;

                        case 3:
                            printf("\nIngrese el sueldo: ");
                            fflush(stdin);
                            scanf("%s", sueldoStr);
                            while(!esNumericoFlotante(sueldoStr) || atof(sueldoStr) > 1000000)
                            {
                                printf("Error. Ingrese el sueldo: ");
                                fflush(stdin);
                                scanf("%s", sueldoStr);
                            }
                            auxEmpleado->sueldo = atof(sueldoStr);
                            todoOk = 1;
                            break;

                        case 4:
                            printf("\nDesea salir?(s/n): ");
                            fflush(stdin);
                            salir = getche();
                            printf("\n\n");

                            while(salir != 's' && salir != 'n')
                            {
                                printf("Error. Ingrese s o n: ");
                                fflush(stdin);
                                salir = getche();
                                printf("\n\n");
                            }
                            break;
                    }
                }
                while(salir == 'n');
            }
        }
    }
    return todoOk;
}

/** \brief Baja de empleado
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int Retorna 1 si se dio de baja el empleado
 *
 */
int controller_removeEmployee(LinkedList* pArrayListEmployee)
{
    int todoOk = 0;
    int largoArray = 0;
    int i = 0;
    int flag = 0;
    char idStr[10];
    char salir;
    eEmployee* auxEmpleado = NULL;

    if(pArrayListEmployee != NULL)
    {
        largoArray = ll_len(pArrayListEmployee);

        if(controller_ListEmployee(pArrayListEmployee) == 0)
        {
            printf("\nNo hay empleados por remover.\n");
        }
        else
        {
            printf("\nIngrese el id del empleado a remover: ");
            fflush(stdin);
            scanf("%s", idStr);
            while(!esNumerico(idStr))
            {
                printf("Error. Ingrese un id valido: ");
                fflush(stdin);
                scanf("%s", idStr);
            }
             for(i=0; i < largoArray; i++)
            {
                auxEmpleado = (eEmployee*) ll_get(pArrayListEmployee, i);
                if(auxEmpleado->id == atoi(idStr))
                {
                    flag = 1;
                    break;
                }
            }
            if(flag)
            {
                printf("\nDesea eliminar?(s/n): ");
                fflush(stdin);
                salir = getche();
                while(salir != 's' && salir != 'n')
                {
                    printf("\nError. Ingrese s o n: ");
                    fflush(stdin);
                    salir = getche();
                }
                printf("\n\n");
                if(salir == 's')
                {
                    if(ll_remove(pArrayListEmployee, i) == 0)
                    {
                          todoOk = 1;
                    }
                }
            }
            else
            {
                printf("No hay empleado con es id.\n");
            }
        }
    }

    return todoOk;
}

/** \brief Listar empleados
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int Retorna la cantidad de empleados en la lista
 *
 */
int controller_ListEmployee(LinkedList* pArrayListEmployee)
{
    int contador = 0;
    int largoArray = 0;
    eEmployee* auxEmpleado = NULL;

    if(pArrayListEmployee != NULL)
    {
        largoArray = ll_len(pArrayListEmployee);

        for(contador = 0; contador < largoArray; contador++)
        {
            if(contador == 0)
            {
                printf("\n|   Id   |       Nombre       |  Horas trabajadas |  Sueldo    |\n");
                printf("----------------------------------------------------------------\n");
            }

            auxEmpleado = (eEmployee*) ll_get(pArrayListEmployee, contador);

            if(auxEmpleado != NULL)
            {
                printf("| %4d   |  %15s   |        %4d       |   %4.2f |\n", auxEmpleado->id, auxEmpleado->nombre, auxEmpleado->horasTrabajadas, auxEmpleado->sueldo);
            }
        }
    }

    return contador;
}

/** \brief Ordenar empleados
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int controller_sortEmployee(LinkedList* pArrayListEmployee)
{
    int todoOk = 0;
    char order[2];

    if(pArrayListEmployee != NULL)
    {
        printf("\nIngrese 1 para ordenar de forma ascedente y 0 para ordenar de forma descente: ");
        fflush(stdin);
        scanf("%s", order);
        while(!esNumerico(order) || atoi(order) > 1)
        {
            printf("Error. Ingrese 1 para ordenar de forma ascedente y 0 para ordenar de forma descente: ");
            fflush(stdin);
            scanf("%s", order);
        }

     if(ll_sort(pArrayListEmployee, sortEmployee, atoi(order)) == 0)
     {
         todoOk = 1;
     }
    }

    return todoOk;
}

/** \brief Guarda los datos de los empleados en el archivo data.csv (modo texto).
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int Retorna 1 si se guardaron los datos
 *
 */
int controller_saveAsText(char* path , LinkedList* pArrayListEmployee)
{
    int todoOk = 0;
    int i;
    int largoArray = 0;
    FILE* file = NULL;
    eEmployee* auxEmpleado = NULL;

    if(pArrayListEmployee != NULL && path != NULL)
    {
        largoArray = ll_len(pArrayListEmployee);

        file = fopen(path, "w");
        if(file == NULL)
        {
            return todoOk;
        }
        if(largoArray > 0)
        {
            fprintf(file, "id,nombre,horasTrabajadas,sueldo\n");
            for(i=0; i < largoArray; i++)
            {
                auxEmpleado = (eEmployee*) ll_get(pArrayListEmployee, i);
                if(auxEmpleado != NULL)
                {
                    fprintf(file, "%d,%s,%d,%f\n", auxEmpleado->id, auxEmpleado->nombre, auxEmpleado->horasTrabajadas, auxEmpleado->sueldo);
                }
                else
                {
                    break;
                }
            }
            if(i == largoArray)
            {
                todoOk = 1;
            }
        }
        fclose(file);
    }
    return todoOk;
}

/** \brief Guarda los datos de los empleados en el archivo data.csv (modo binario).
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int Retorna 1 si se guardaron los datos
 *
 */
int controller_saveAsBinary(char* path , LinkedList* pArrayListEmployee)
{
    int todoOk = 0;
    int i;
    int largoArray = 0;
    FILE* file = NULL;
    eEmployee* auxEmpleado = NULL;

    if(pArrayListEmployee != NULL && path != NULL)
    {
        largoArray = ll_len(pArrayListEmployee);

        file = fopen(path, "wb");
        if(file == NULL)
        {
            return todoOk;
        }
        if(largoArray > 0)
        {
            for(i=0; i < largoArray; i++)
            {
                auxEmpleado = (eEmployee*) ll_get(pArrayListEmployee, i);
                if(auxEmpleado != NULL)
                {
                    fwrite((eEmployee*) auxEmpleado, sizeof(eEmployee), 1, file);
                }
                else
                {
                    break;
                }
            }
            if(i == largoArray)
            {
                todoOk = 1;
            }
        }
        fclose(file);
    }
    return todoOk;
}


/** \brief Ordena las estructuras alfabeticamente
 *
 * \param emp1 void* puntero a void
 * \param emp2 void* puntero a void
 * \return int Retorna el orden
 *
 */
int sortEmployee(void* emp1, void* emp2)
{
    int orden;
    eEmployee* auxEmp1 = NULL;
    eEmployee* auxEmp2 = NULL;

    if(emp1 != NULL && emp2 != NULL)
    {
        auxEmp1 = (eEmployee*) emp1;
        auxEmp2 = (eEmployee*) emp2;

        if(strcmp(auxEmp1->nombre, auxEmp2->nombre) > 0)
        {
            orden = 1;
        }
        else if(strcmp(auxEmp1->nombre, auxEmp2->nombre) < 0)
        {
            orden = -1;
        }
        else
        {
            orden = 0;
        }
    }
    return orden;
}
