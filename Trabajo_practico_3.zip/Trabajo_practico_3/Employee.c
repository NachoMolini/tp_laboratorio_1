#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Employee.h"

/** \brief Busca espacio en memoria para una estructura de e inicializa los valores de la misma
 *
 * \return eEmpleado* Retorna un puntero a eEmpleado
 *
 */
eEmployee* employee_new()
{
    eEmployee* nuevo = (eEmployee*) malloc(sizeof(eEmployee));

    if(nuevo != NULL)
    {
        nuevo->id = 0;
        strcpy(nuevo->nombre, " ");
        nuevo->horasTrabajadas = 0;
        nuevo->sueldo = 0;
    }

    return nuevo;
}

/** \brief Carga los valores que se le pasan por parametro a una nueva estructura de empleado
 *
 * \param idSt char* Direccion de memoria del id
 * \param nombreStr char* Direccion de memoria del nombre
 * \param horasTrabajadasStr char* Direccion de memoria de las horas trabajadas
 * \param sueldoStr char* Direccion de memoria del sueldo
 * \return eEmpleado* Retorna un puntero a eEmpleado
 *
 */
eEmployee* employee_newParametros(char* idStr, char* nombreStr, char* horasTrabajadasStr, char* sueldoStr)
{
    eEmployee* nuevo = employee_new();

    if(nuevo != NULL && (!employee_setId(nuevo, atoi(idStr)) || !employee_setNombre(nuevo, nombreStr) ||
      !employee_setHorasTrabajadas(nuevo, atoi(horasTrabajadasStr)) || !employee_setSueldo(nuevo, atof(sueldoStr))))
    {
        free(nuevo);
        nuevo = NULL;
    }

    return nuevo;
}


/** \brief Carga en la estructura  de empleado el id que se le pasa por parametro
 *
 * \param this eEmployee* Direccion de memoria de la estructura
 * \param id int valor del id
 * \return int Retorna 1 si se cargo el valor y 0 si no
 *
 */
int employee_setId(eEmployee* this, int id)
{
    int todoOk = 0;

    if(this != NULL && id > 0 && id <= 2000)
    {
        this->id = id;
        todoOk = 1;
    }

    return todoOk;
}

/** \brief Carga en el lugar donde apunta la direccion de memoria que se le pasa el valor de la estructura
 *
 * \param this eEmployee* Direccion de memoria de la estructura
 * \param id int* Direccion de memoria del id
 * \return int Retorna 1 si se cargo el valor y 0 si no
 *
 */
int employee_getId(eEmployee* this, int* id)
{
    int todoOk = 0;

    if(this != NULL)
    {
        *id = this->id;
        todoOk = 1;
    }

    return todoOk;
}


/** \brief Carga en la estructura  de empleado el nombre que se le pasa por parametro
 *
 * \param this eEmployee* Direccion de memoria de la estructura
 * \param nombre char* Direccion de memoria del nombre
 * \return int Retorna 1 si se cargo el valor y 0 si no
 *
 */
int employee_setNombre(eEmployee* this, char* nombre)
{
    int todoOk = 0;

    if(this != NULL && nombre != NULL)
    {
        strcpy(this->nombre, nombre);
        todoOk = 1;
    }

    return todoOk;
}


/** \brief Carga en el lugar donde apunta la direccion de memoria que se le pasa el valor de la estructura
 *
 * \param this eEmployee* Direccion de memoria de la estructura
 * \param nombre char* Direccion de memoria del nombre
 * \return int Retorna 1 si se cargo el valor y 0 si no
 *
 */
int employee_getNombre(eEmployee* this, char* nombre)
{
    int todoOk = 0;

    if(this != NULL && nombre != NULL)
    {
        strcpy(nombre, this->nombre);
        todoOk = 1;
    }

    return todoOk;
}


/** \brief Carga en la estructura  de empleado las horas trabajadas que se le pasa por parametro
 *
 * \param this eEmployee* Direccion de memoria de la estructura
 * \param horasTrabajadas int Valor de las horas trabajadas
 * \return int Retorna 1 si se cargo el valor y 0 si no
 *
 */
int employee_setHorasTrabajadas(eEmployee* this,int horasTrabajadas)
{
    int todoOk = 0;

    if(this != NULL && horasTrabajadas >= 0)
    {
        this->horasTrabajadas = horasTrabajadas;
        todoOk = 1;
    }

    return todoOk;
}


/** \brief Carga en el lugar donde apunta la direccion de memoria que se le pasa el valor de la estructura
 *
 * \param this eEmployee* Direccion de memoria de la estructura
 * \param horasTrabajadas int* Direccion de memoria de las horas trabajadas
 * \return int Retorna 1 si se cargo el valor y 0 si no
 *
 */
int employee_getHorasTrabajadas(eEmployee* this, int* horasTrabajadas)
{
    int todoOk = 0;

    if(this != NULL && horasTrabajadas != NULL)
    {
        *horasTrabajadas = this->horasTrabajadas;
        todoOk = 1;
    }

    return todoOk;
}


/** \brief Carga en la estructura  de empleado el sueldo que se le pasa por parametro
 *
 * \param this eEmployee* Direccion de memoria de la estructura
 * \param sueldo float Valor del sueldo
 * \return int Retorna 1 si se cargo el valor y 0 si no
 *
 */
int employee_setSueldo(eEmployee* this, float sueldo)
{
    int todoOk = 0;

    if(this != NULL && sueldo >= 0)
    {
        this->sueldo = sueldo;
        todoOk = 1;
    }

    return todoOk;
}

/** \brief Carga en el lugar donde apunta la direccion de memoria que se le pasa el valor de la estructura
 *
 * \param this eEmployee* Direccion de memoria de la estructura
 * \param sueldo float* Direccion de memoria del sueldo
 * \return int Retorna 1 si se cargo el valor y 0 si no
 *
 */
int employee_getSueldo(eEmployee* this, float* sueldo)
{
    int todoOk = 0;

    if(this != NULL && sueldo != NULL)
    {
        *sueldo = this->sueldo;
        todoOk = 1;
    }

    return todoOk;
}


