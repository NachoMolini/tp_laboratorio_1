#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include "LinkedList.h"
#include "Controller.h"
#include "Employee.h"
#include "menu.h"

/****************************************************
    Menu:
     1. Cargar los datos de los empleados desde el archivo data.csv (modo texto).
     2. Cargar los datos de los empleados desde el archivo data.bin (modo binario).
     3. Alta de empleado
     4. Modificar datos de empleado
     5. Baja de empleado
     6. Listar empleados
     7. Ordenar empleados
     8. Guardar los datos de los empleados en el archivo data.csv (modo texto).
     9. Guardar los datos de los empleados en el archivo data.bin (modo binario).
    10. Salir
*****************************************************/

int main()
{
    char salir = 'n';
    int cantidadEmpleados;
    int* cantidadEmpleadosP = &cantidadEmpleados;
    int flag = 0;
    LinkedList* listaEmpleados = ll_newLinkedList();

    do{
        switch(menu())
        {
            case 1:
                if(!flag)
                {
                    cantidadEmpleados = controller_loadFromText("data.csv",listaEmpleados);
                    if(cantidadEmpleados > 0)
                    {
                        printf("\nSe cargaron en el sistema %d empleados.\n\n", cantidadEmpleados);
                        flag = 1;
                    }
                    else
                    {
                        printf("\nNo se pudo cargar ningun empleado.\n\n");
                    }
                }
                else
                {
                    printf("\nYa se cargaron los empleados anteriormente.\n\n");
                }
                break;

            case 2:
                if(!flag)
                {
                    cantidadEmpleados = controller_loadFromBinary("data.bin", listaEmpleados);
                    if(cantidadEmpleados > 0)
                    {
                        printf("\nSe cargaron en el sistema %d empleados.\n\n", cantidadEmpleados);
                        flag = 1;
                    }
                    else
                    {
                        printf("\nNo se pudo cargar ningun empleado.\n\n");
                    }
                }
                else
                {
                    printf("\nYa se cargaron los empleados anteriormente.\n\n");
                }
                break;

            case 3:
                controller_addEmployee(listaEmpleados, cantidadEmpleadosP);
                break;

            case 4:
                if(controller_editEmployee(listaEmpleados))
                {
                    system("cls");
                    printf("\nSe modifico con exito el empleado!\n\n");
                }
                break;

            case 5:
                if(controller_removeEmployee(listaEmpleados))
                {
                    system("cls");
                    printf("\nSe dio de baja con exito el empleado!\n\n");
                }
                break;

            case 6:
                cantidadEmpleados = controller_ListEmployee(listaEmpleados);
                if(cantidadEmpleados == 0)
                {
                    system("cls");
                    printf("\nNo hay empleados por mostrar.\n\n");
                }
                break;

            case 7:
                if(controller_sortEmployee(listaEmpleados))
                {
                    system("cls");
                    printf("Se han ordenado alfabeticamente los nombres!\n\n");
                }
                break;

            case 8:
                if(ll_len(listaEmpleados) > 0)
                {
                    if(controller_saveAsText("data.csv",listaEmpleados))
                    {
                         printf("\nEmpleados guardados correctamente en modo texto.\n\n");
                    }
                    else
                    {
                        printf("\nNo se guardaron los empleados.\n\n");
                    }
                }
                else
                {
                    printf("\nNo hay empleados en el sistema.\n\n");
                }
                break;

            case 9:
                if(ll_len(listaEmpleados) > 0)
                {
                    if(controller_saveAsBinary("data.bin",listaEmpleados))
                    {
                         printf("\nEmpleados guardados correctamente en modo binario.\n\n");
                    }
                    else
                    {
                        printf("\nNo se guardaron los empleados.\n\n");
                    }
                }
                else
                {
                    printf("\nNo hay empleados en el sistema.\n\n");
                }

                break;

            case 10:
                printf("\nDesea salir?(s/n): ");
                fflush(stdin);
                salir = getche();
                while(salir != 's' && salir != 'n')
                {
                    printf("\nError. Ingrese s o n: ");
                    fflush(stdin);
                    salir = getche();
                }
                printf("\n\n");
                break;
        }

        system("pause");

    }while(salir == 'n');

    return 0;
}




