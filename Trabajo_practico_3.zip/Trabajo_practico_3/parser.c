#include <stdio.h>
#include <stdlib.h>
#include "LinkedList.h"
#include "Employee.h"

/** \brief Parsea los datos los datos de los empleados desde el archivo data.csv (modo texto).
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int Retorna la cantidad de empleados que se cargaron
 *
 */
int parser_EmployeeFromText(FILE* pFile , LinkedList* pArrayListEmployee)
{
    int contador = 0;
    int cantidad = 0;
    char buffer[4][128];
    eEmployee* auxEmpleado;

    if(pFile == NULL || pArrayListEmployee == NULL)
    {
        printf("El archivo no existe o no se pudo conseguir memoria.\n");
        exit(EXIT_FAILURE);
    }

    while(!feof(pFile))
    {
        cantidad = fscanf(pFile, "%[^,],%[^,],%[^,],%[^\n]\n", buffer[0], buffer[1], buffer[2], buffer[3]);
        if(cantidad < 4)
        {
            break;
        }
        else
        {
            auxEmpleado = employee_newParametros(buffer[0], buffer[1], buffer[2], buffer[3]);

            if(auxEmpleado != NULL && ll_len(pArrayListEmployee) < 2000
               && ll_add(pArrayListEmployee, (eEmployee*)auxEmpleado) == 0)
            {
                contador++;
            }
        }
    }

    return contador;
}

/** \brief Parsea los datos los datos de los empleados desde el archivo data.bin (modo binario).
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int Retorna la cantidad de empleados que se cargaron
 *
 */
int parser_EmployeeFromBinary(FILE* pFile , LinkedList* pArrayListEmployee)
{
    int contador = 0;
    int cantidad = 0;
    eEmployee* auxEmpleado = NULL;

    if(pFile == NULL || pArrayListEmployee == NULL)
    {
        printf("El archivo no existe o no se pudo conseguir memoria.\n");
        exit(EXIT_FAILURE);
    }


    while(!feof(pFile))
    {
        auxEmpleado = employee_new();

        if(auxEmpleado == NULL)
        {
            break;
        }
        cantidad = fread((eEmployee*)auxEmpleado, sizeof(eEmployee), 1, pFile);
        if(cantidad  < 1)
        {
            break;
        }
        else if(ll_len(pArrayListEmployee) < 2000 && !ll_add(pArrayListEmployee, (eEmployee*)auxEmpleado))
        {
            contador++;
        }
    }
    return contador;
}
