int esNumerico(char str[]);
int esSoloLetras(char str[]);
int esNumericoFlotante(char str[]);
