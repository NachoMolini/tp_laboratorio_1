#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Car.h"

/** \brief Busca espacio en memoria para una estructura de e inicializa los valores de la misma
 *
 * \return eCar* Retorna un puntero a eCar
 *
 */
eCar* car_new()
{
    eCar* nuevo = (eCar*) malloc(sizeof(eCar));

    if(nuevo != NULL)
    {
        nuevo->id = 0;
        strcpy(nuevo->marca, " ");
        strcpy(nuevo->modelo, " ");
        nuevo->anio = 0;
    }

    return nuevo;
}

/** \brief Carga los valores que se le pasan por parametro a una nueva estructura de auto
 *
 * \param idSt char* Direccion de memoria del id
 * \param marcaStr char* Direccion de memoria de la marca
 * \param modeloStr char* Direccion de memoria del modelo
 * \param anioStr char* Direccion de memoria del anio
 * \return eCar* Retorna un puntero a eCar
 *
 */
eCar* car_newParametros(char* idStr, char* marcaStr, char* modeloStr, char* anioStr)
{
    eCar* nuevo = car_new();

    if(nuevo != NULL && (!car_setId(nuevo, atoi(idStr)) || !car_setMarca(nuevo, marcaStr) ||
      !car_setModelo(nuevo, modeloStr) || !car_setAnio(nuevo, atoi(anioStr))))
    {
        free(nuevo);
        nuevo = NULL;
    }

    return nuevo;
}


/** \brief Carga en la estructura  de auto el id que se le pasa por parametro
 *
 * \param this eCar* Direccion de memoria de la estructura
 * \param id int Valor del id
 * \return int Retorna 1 si se cargo el valor y 0 si no
 *
 */
int car_setId(eCar* this, int id)
{
    int todoOk = 0;

    if(this != NULL && id > 0 && id <= 2000)
    {
        this->id = id;
        todoOk = 1;
    }

    return todoOk;
}

/** \brief Carga en el lugar donde apunta la direccion de memoria que se le pasa el valor de la estructura
 *
 * \param this eCar* Direccion de memoria de la estructura
 * \param id int* Direccion de memoria del id
 * \return int Retorna 1 si se cargo el valor y 0 si no
 *
 */
int care_getId(eCar* this, int* id)
{
    int todoOk = 0;

    if(this != NULL)
    {
        *id = this->id;
        todoOk = 1;
    }

    return todoOk;
}


/** \brief Carga en la estructura  de auto la marca que se le pasa por parametro
 *
 * \param this eCar* Direccion de memoria de la estructura
 * \param marca char* Direccion de memoria de la marca
 * \return int Retorna 1 si se cargo el valor y 0 si no
 *
 */
int car_setMarca(eCar* this, char* marca)
{
    int todoOk = 0;

    if(this != NULL && marca != NULL)
    {
        strcpy(this->marca, marca);
        todoOk = 1;
    }

    return todoOk;
}


/** \brief Carga en el lugar donde apunta la direccion de memoria que se le pasa el valor de la estructura
 *
 * \param this eCar* Direccion de memoria de la estructura
 * \param marca char* Direccion de memoria de la marca
 * \return int Retorna 1 si se cargo el valor y 0 si no
 *
 */
int car_getMarca(eCar* this, char* marca)
{
    int todoOk = 0;

    if(this != NULL && marca != NULL)
    {
        strcpy(marca, this->marca);
        todoOk = 1;
    }

    return todoOk;
}


/** \brief Carga en la estructura  de auto el modelo que se le pasa por parametro
 *
 * \param this eCar* Direccion de memoria de la estructura
 * \param modelo char Nombre del modelo
 * \return int Retorna 1 si se cargo el valor y 0 si no
 *
 */
int car_setModelo(eCar* this, char* modelo)
{
    int todoOk = 0;

    if(this != NULL && modelo >= 0)
    {
        strcpy(this->modelo, modelo);
        todoOk = 1;
    }

    return todoOk;
}


/** \brief Carga en el lugar donde apunta la direccion de memoria que se le pasa el valor de la estructura
 *
 * \param this eCar* Direccion de memoria de la estructura
 * \param modelo char* Direccion de memoria del modelo
 * \return int Retorna 1 si se cargo el valor y 0 si no
 *
 */
int car_getModelo(eCar* this, char* modelo)
{
    int todoOk = 0;

    if(this != NULL && modelo != NULL)
    {
        strcpy(modelo, this->modelo);
        todoOk = 1;
    }

    return todoOk;
}


/** \brief Carga en la estructura  de auto el anio que se le pasa por parametro
 *
 * \param this eCar* Direccion de memoria de la estructura
 * \param anio int Valor del anio
 * \return int Retorna 1 si se cargo el valor y 0 si no
 *
 */
int car_setAnio(eCar* this, int anio)
{
    int todoOk = 0;

    if(this != NULL && anio >= 0)
    {
        this->anio = anio;
        todoOk = 1;
    }

    return todoOk;
}

/** \brief Carga en el lugar donde apunta la direccion de memoria que se le pasa el valor de la estructura
 *
 * \param this eCar* Direccion de memoria de la estructura
 * \param anio int* Direccion de memoria del anio
 * \return int Retorna 1 si se cargo el valor y 0 si no
 *
 */
int car_getSueldo(eCar* this, int* anio)
{
    int todoOk = 0;

    if(this != NULL && anio != NULL)
    {
        *anio = this->anio;
        todoOk = 1;
    }

    return todoOk;
}
