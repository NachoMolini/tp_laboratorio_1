#ifndef car_H_INCLUDED
#define car_H_INCLUDED

typedef struct
{
    int id;
    char marca[50];
    char modelo[50];
    int anio;

}eCar;

#endif

eCar* car_new();
eCar* car_newParametros(char* idStr, char* marcaStr, char* modeloStr, char* anioStr);
void car_delete();

int car_setId(eCar* this, int id);
int car_getId(eCar* this, int* id);

int car_setNombre(eCar* this, char* nombre);
int car_getNombre(eCar* this, char* nombre);

int car_setHorasTrabajadas(eCar* this, char* modelo);
int car_getHorasTrabajadas(eCar* this, char* modelo);

int car_setSueldo(eCar* this, int anio);
int car_getSueldo(eCar* this, int* anio);
