#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include "LinkedList.h"
#include "Controller.h"
#include "Car.h"
#include "parser.h"
#include "validaciones.h"


/** \brief Carga los datos de los autos desde el archivo data.csv (modo texto).
 *
 * \param path char*
 * \param pArrayListCar LinkedList*
 * \return int Retorna la cantidad de autos cargados
 *
 */
int controller_loadFromText(char* path , LinkedList* pArrayListCar)
{
    int contador = 0;
    FILE* file = NULL;

    if(pArrayListCar != NULL && path != NULL)
    {
        file = fopen(path, "r");

        if(file != NULL)
        {
            contador = parser_CarFromText(file, pArrayListCar);
        }
    }

    fclose(file);

    return contador;
}

/** \brief Carga los datos de los autos desde el archivo data.csv (modo binario).
 *
 * \param path char*
 * \param pArrayListCar LinkedList*
 * \return int Retorna la cantidad de autos cargados
 *
 */
int controller_loadFromBinary(char* path , LinkedList* pArrayListCar)
{
    int contador = 0;
    FILE* file = NULL;

    if(pArrayListCar != NULL && path != NULL)
    {
        file = fopen(path, "rb");

        if(file != NULL)
        {
            contador = parser_CarFromBinary(file, pArrayListCar);

        }
    }

    fclose(file);

    return contador;
}

/** \brief Alta de autos
 *
 * \param pArrayListCar LinkedList*
 * \return int Retorna 1 si se pudo agregar un auto
 *
 */
int controller_addCar(LinkedList* pArrayListCar, int* cantidadAutosP, int contador)
{
    int todoOk = 0;
    eCar* nuevoAuto = NULL;
    char idStr[10];
    char marca[50];
    char modelo[50];
    char anioStr[10];

    int largoArray = ll_len(pArrayListCar);

    if(largoArray >= 2000)
    {
        printf("No hay mas espacio para cargar autos.\n");
    }
    else if(ll_isEmpty(pArrayListCar))
    {
        printf("Primero debe cargar los autos del archivo.\n");
    }
    else
    {
        sprintf(idStr, "%d", (*cantidadAutosP)+contador);

        printf("Ingrese la marca: ");
        fflush(stdin);
        gets(marca);
        while(!esSoloLetrasYGuiones(marca))
        {
            printf("Error. Ingrese el marca: ");
            fflush(stdin);
            gets(marca);
        }
        primeraLetraMayus(marca);

        printf("Ingrese el modelo: ");
        fflush(stdin);
        gets(modelo);
        while(!esAlfaNumericoYGuiones(modelo))
        {
            printf("Error. Ingrese el modelo: ");
            fflush(stdin);
            gets(modelo);
        }
        primeraLetraMayus(modelo);

        printf("Ingrese el anio: ");
        fflush(stdin);
        scanf("%s", anioStr);
        while(!esNumerico(anioStr) || atoi(anioStr) > 2019 || atoi(anioStr) < 1920)
        {
            printf("Error. Ingrese anio: ");
            fflush(stdin);
            scanf("%s", anioStr);
        }
    }

    nuevoAuto = car_newParametros(idStr, marca, modelo, anioStr);

    if(nuevoAuto != NULL)
    {
        if(ll_add(pArrayListCar, (eCar*) nuevoAuto) == 0)
        {
            printf("\nSe cargo con exito el nuevo auto!\n\n");
            todoOk = 1;
        }
    }

    return todoOk;
}

/** \brief Modificar datos de auto
 *
 * \param path char*
 * \param pArrayListCar LinkedList*
 * \return int Retorna 1 si se pudo editar el auto
 *
 */
int controller_editCar(LinkedList* pArrayListCar)
{
    int todoOk = 0;
    int flag = 0;
    int opcion;
    char salir = 'n';
    char idStr[10];
    char marca[128];
    char modelo[10];
    char anioStr[10];
    int largoArray = 0;
    eCar* auxAuto = NULL;

    if(pArrayListCar != NULL)
    {
        largoArray = ll_len(pArrayListCar);

        if(ll_isEmpty(pArrayListCar))
        {
            printf("No hay autos por editar.\n");
        }
        else
        {
            do
            {
                printf("\nIngrese el id del auto a modificar: ");
                fflush(stdin);
                scanf("%s", idStr);
                while(!esNumerico(idStr))
                {
                    printf("Error. Ingrese un id valido: ");
                    fflush(stdin);
                    scanf("%s", idStr);
                }
                for(int i=0; i < largoArray; i++)
                {
                    auxAuto = (eCar*) ll_get(pArrayListCar, i);
                    if(auxAuto->id == atoi(idStr))
                    {
                        flag = 1;
                        break;
                    }
                }
                if(!flag)
                {
                    printf("Error. No existe empleado con ese id\n");
                }

            }while(flag == 0);

            if(auxAuto != NULL)
            {
                do
                {
                    system("cls");

                    printf("***** Modificar auto *****\n\n");

                    printf("\n|   Id   |       Marca       |             Modelo          |  Anio  |\n");
                    printf("---------------------------------------------------------------------\n");
                    printf("| %4d   |  %15s  |  %25s  |  %4d  |\n", auxAuto->id, auxAuto->marca, auxAuto->modelo, auxAuto->anio);

                    printf("\n1- Modificar marca\n");
                    printf("2- Modificar modelo\n");
                    printf("3- Modificar anio\n");
                    printf("4- Salir\n\n");
                    printf("Ingrese opcion: ");
                    scanf("%d", &opcion);
                    while(opcion < 1 || opcion > 4)
                    {
                        printf("Error. Ingrese una opcion valida: ");
                        scanf("%d", &opcion);
                    }

                    switch(opcion)
                    {
                        case 1:
                            printf("Ingrese la marca: ");
                            fflush(stdin);
                            gets(marca);
                            while(!esSoloLetrasYGuiones(marca))
                            {
                                printf("Error. Ingrese la marca: ");
                                fflush(stdin);
                                gets(marca);
                            }
                            primeraLetraMayus(marca);
                            strcpy(auxAuto->marca, marca);
                            todoOk = 1;
                            break;

                        case 2:
                            printf("Ingrese el modelo: ");
                            fflush(stdin);
                            gets(modelo);
                            while(!esAlfaNumericoYGuiones(modelo))
                            {
                                printf("Error. Ingrese el modelo: ");
                                fflush(stdin);
                                gets(modelo);
                            }
                            primeraLetraMayus(modelo);
                            strcpy(auxAuto->modelo, modelo);
                            todoOk = 1;
                            break;

                        case 3:
                            printf("Ingrese el anio: ");
                            fflush(stdin);
                            scanf("%s", anioStr);
                            while(!esNumerico(anioStr) || atoi(anioStr) > 2019 || atoi(anioStr) < 1920)
                            {
                                printf("Error. Ingrese el anio: ");
                                fflush(stdin);
                                scanf("%s", anioStr);
                            }
                            auxAuto->anio = atoi(anioStr);
                            todoOk = 1;
                            break;

                        case 4:
                            printf("\nDesea salir?(s/n): ");
                            fflush(stdin);
                            salir = getche();
                            printf("\n\n");

                            while(salir != 's' && salir != 'n')
                            {
                                printf("Error. Ingrese s o n: ");
                                fflush(stdin);
                                salir = getche();
                                printf("\n\n");
                            }
                            break;
                    }
                }
                while(salir == 'n');
            }
        }
    }
    return todoOk;
}

/** \brief Baja de auto
 *
 * \param path char*
 * \param pArrayListCar LinkedList*
 * \return int Retorna 1 si se dio de baja el auto
 *
 */
int controller_removeCar(LinkedList* pArrayListCar)
{
    int todoOk = 0;
    int largoArray = 0;
    int i = 0;
    int flag = 0;
    char idStr[10];
    char salir;
    eCar* auxAuto = NULL;

    if(pArrayListCar != NULL)
    {
        largoArray = ll_len(pArrayListCar);

        if(ll_isEmpty(pArrayListCar))
        {
            printf("\nNo hay autos por remover.\n\n");
        }
        else
        {
            printf("\nIngrese el id del auto a remover: ");
            fflush(stdin);
            scanf("%s", idStr);
            while(!esNumerico(idStr))
            {
                printf("Error. Ingrese un id valido: ");
                fflush(stdin);
                scanf("%s", idStr);
            }
             for(i=0; i < largoArray; i++)
            {
                auxAuto = (eCar*) ll_get(pArrayListCar, i);
                if(auxAuto->id == atoi(idStr))
                {
                    flag = 1;
                    break;

                }
            }
            if(flag)
            {
                printf("\n|   Id   |       Marca       |             Modelo          |  Anio  |\n");
                printf("---------------------------------------------------------------------\n");
                printf("| %4d   |  %15s  |  %25s  |  %4d  |\n", auxAuto->id, auxAuto->marca, auxAuto->modelo, auxAuto->anio);
                printf("\nDesea eliminar?(s/n): ");
                fflush(stdin);
                salir = getche();
                while(salir != 's' && salir != 'n')
                {
                    printf("\nError. Ingrese s o n: ");
                    fflush(stdin);
                    salir = getche();
                }
                printf("\n\n");
                if(salir == 's')
                {
                    if(ll_remove(pArrayListCar, i) == 0)
                    {
                        printf("Se ha eliminado con exito!\n\n");
                        todoOk = 1;
                    }
                }
                else
                {
                    printf("No se ha eliminado.\n\n");
                }
            }
            else
            {
                printf("No hay auto con es id.\n");
            }
        }
    }

    return todoOk;
}

/** \brief Listar autos
 *
 * \param path char*
 * \param pArrayListCar LinkedList*
 * \return int Retorna la cantidad de autos en la lista
 *
 */
int controller_ListCar(LinkedList* pArrayListCar)
{
    int contador = 0;
    int largoArray = 0;
    int i;
    int j;
    int desde = 0;
    int hasta = 20;
    char opcion[2];
    eCar* auxAuto = NULL;
    LinkedList* subLista = NULL;

    if(pArrayListCar != NULL)
    {
        if(ll_isEmpty(pArrayListCar))
        {
            printf("\nNo hay autos por mostrar.\n\n");
            return contador;
        }

        largoArray = ll_len(pArrayListCar);

        printf("Ingrese 1 para mostra la lista entera y 2 para mostrarla en partes: ");
        fflush(stdin);
        scanf("%s", opcion);
        while(!esNumerico(opcion) || atoi(opcion) < 1 || atoi(opcion) > 2)
        {
            printf("Error. Ingrese 1 para mostra la lista entera y 2 para mostrarla en partes: ");
            fflush(stdin);
            scanf("%s", opcion);
        }

         system("cls");

        switch(atoi(opcion))
        {
            case 1:
                for(contador = 0; contador < largoArray; contador++)
                {
                    if(contador == 0)
                    {
                        printf("\n|   Id   |       Marca       |             Modelo          |  Anio  |\n");
                        printf("---------------------------------------------------------------------\n");
                    }

                    auxAuto = (eCar*) ll_get(pArrayListCar, contador);

                    if(auxAuto != NULL)
                    {
                        printf("| %4d   |  %15s  |  %25s  |  %4d  |\n", auxAuto->id, auxAuto->marca, auxAuto->modelo, auxAuto->anio);
                    }
                }
                return contador;

            case 2:
                for(contador=0; contador < largoArray; contador++)
                {
                    subLista = ll_subList(pArrayListCar, desde, hasta);
                    for( i=0; i < ll_len(subLista); i++)
                    {
                        if(i == 0)
                        {
                            printf("\n|   Id   |       Marca       |             Modelo          |  Anio  |\n");
                            printf("---------------------------------------------------------------------\n");
                        }
                        auxAuto = (eCar*) ll_get(subLista, i);
                        if(auxAuto != NULL)
                        {
                            printf("| %4d   |  %15s  |  %25s  |  %4d  |\n", auxAuto->id, auxAuto->marca, auxAuto->modelo, auxAuto->anio);
                        }
                    }
                    if(hasta >= largoArray)
                    {
                        subLista = ll_subList(pArrayListCar, desde, largoArray);
                        for( j=0; j < ll_len(subLista); j++)
                        {
                            if(j == 0)
                            {
                                printf("\n|   Id   |       Marca       |             Modelo          |  Anio  |\n");
                                printf("---------------------------------------------------------------------\n");
                            }
                            auxAuto = (eCar*) ll_get(subLista, j);
                            if(auxAuto != NULL)
                            {
                                printf("| %4d   |  %15s  |  %25s  |  %4d  |\n", auxAuto->id, auxAuto->marca, auxAuto->modelo, auxAuto->anio);
                            }
                        }
                        break;
                    }
                    desde += 20;
                    hasta += 20;
                    system("pause");
                    system("cls");
                }
                contador = (contador*20) + j;
                return contador;
        }
    }
    return contador;
}

/** \brief Ordenar autos
 *
 * \param path char*
 * \param pArrayListCar LinkedList*
 * \return int
 *
 */
int controller_sortCar(LinkedList* pArrayListCar)
{
    int todoOk = 0;
    char opcion[2];
    char order[2];

    printf("\n1. Ordenar por marca\n");
    printf("2. Ordenar por modelo\n");
    printf("3. Ordenar por anio\n");

    printf("\nIngrese una de las opciones: ");
    fflush(stdin);
    gets(opcion);
    while(!esNumerico(opcion) || atoi(opcion) < 1 || atoi(opcion) > 3)
    {
        printf("\nError. Ingrese una de las opciones: ");
        fflush(stdin);
        gets(opcion);
    }

    switch(atoi(opcion))
    {
        case 1:
            if(pArrayListCar != NULL)
            {
                printf("\nIngrese 1 para ordenar de forma ascedente y 0 para ordenar de forma descente: ");
                fflush(stdin);
                scanf("%s", order);
                while(!esNumerico(order) || atoi(order) > 1)
                {
                    printf("Error. Ingrese 1 para ordenar de forma ascedente y 0 para ordenar de forma descente: ");
                    fflush(stdin);
                    scanf("%s", order);
                }

                if(ll_sort(pArrayListCar, sortCarByBrand, atoi(order)) == 0)
                {
                    todoOk = 1;
                }
            }
            break;

        case 2:
            if(pArrayListCar != NULL)
            {
                printf("\nIngrese 1 para ordenar de forma ascedente y 0 para ordenar de forma descente: ");
                fflush(stdin);
                scanf("%s", order);
                while(!esNumerico(order) || atoi(order) > 1)
                {
                    printf("Error. Ingrese 1 para ordenar de forma ascedente y 0 para ordenar de forma descente: ");
                    fflush(stdin);
                    scanf("%s", order);
                }

                if(ll_sort(pArrayListCar, sortCarByModel, atoi(order)) == 0)
                {
                    todoOk = 1;
                }
            }
            break;

        case 3:
            if(pArrayListCar != NULL)
            {
                printf("\nIngrese 1 para ordenar de forma ascedente y 0 para ordenar de forma descente: ");
                fflush(stdin);
                scanf("%s", order);
                while(!esNumerico(order) || atoi(order) > 1)
                {
                    printf("Error. Ingrese 1 para ordenar de forma ascedente y 0 para ordenar de forma descente: ");
                    fflush(stdin);
                    scanf("%s", order);
                }

                if(ll_sort(pArrayListCar, sortCarByYear, atoi(order)) == 0)
                {
                    todoOk = 1;
                }
            }
            break;
    }

    return todoOk;
}


/** \brief Guarda los datos de los autos en el archivo data.csv (modo texto).
 *
 * \param path char*
 * \param pArrayListCar LinkedList*
 * \return int Retorna 1 si se guardaron los datos
 *
 */
int controller_saveAsText(char* path , LinkedList* pArrayListCar)
{
    int todoOk = 0;
    int i;
    int largoArray = 0;
    FILE* file = NULL;
    eCar* auxAuto = NULL;

    if(pArrayListCar != NULL && path != NULL)
    {
        largoArray = ll_len(pArrayListCar);

        file = fopen(path, "w");
        if(file == NULL)
        {
            return todoOk;
        }
        if(largoArray > 0)
        {
            fprintf(file, "id,marca,modelo,anio\n");
            for(i=0; i < largoArray; i++)
            {
                auxAuto = (eCar*) ll_get(pArrayListCar, i);
                if(auxAuto != NULL)
                {
                    fprintf(file, "%d,%s,%s,%d\n", auxAuto->id, auxAuto->marca, auxAuto->modelo, auxAuto->anio);
                }
                else
                {
                    break;
                }
            }
            if(i == largoArray)
            {
                todoOk = 1;
            }
        }
        fclose(file);
    }
    return todoOk;
}

/** \brief Guarda los datos de los autos en el archivo data.csv (modo binario).
 *
 * \param path char*
 * \param pArrayListCar LinkedList*
 * \return int Retorna 1 si se guardaron los datos
 *
 */
int controller_saveAsBinary(char* path , LinkedList* pArrayListCar)
{
    int todoOk = 0;
    int i;
    int largoArray = 0;
    FILE* file = NULL;
    eCar* auxAuto = NULL;

    if(pArrayListCar != NULL && path != NULL)
    {
        largoArray = ll_len(pArrayListCar);

        file = fopen(path, "wb");
        if(file == NULL)
        {
            return todoOk;
        }
        if(largoArray > 0)
        {
            for(i=0; i < largoArray; i++)
            {
                auxAuto = (eCar*) ll_get(pArrayListCar, i);
                if(auxAuto != NULL)
                {
                    fwrite((eCar*) auxAuto, sizeof(eCar), 1, file);
                }
                else
                {
                    break;
                }
            }
            if(i == largoArray)
            {
                todoOk = 1;
            }
        }
        fclose(file);
    }
    return todoOk;
}


/** \brief Ordena las estructuras por marca
 *
 * \param car1 void* puntero a void
 * \param car2 void* puntero a void
 * \return int Retorna el orden
 *
 */
int sortCarByBrand(void* car1, void* car2)
{
    int orden;
    eCar* auxCar1 = NULL;
    eCar* auxCar2 = NULL;

    if(car1 != NULL && car2 != NULL)
    {
        auxCar1 = (eCar*) car1;
        auxCar2 = (eCar*) car2;

        if(strcmp(auxCar1->marca, auxCar2->marca) > 0)
        {
            orden = 1;
        }
        else if(strcmp(auxCar1->marca, auxCar2->marca) < 0)
        {
            orden = -1;
        }
        else
        {
            orden = 0;
        }
    }
    return orden;
}


/** \brief Ordena las estructuras por modelo
 *
 * \param car1 void* puntero a void
 * \param car2 void* puntero a void
 * \return int Retorna el orden
 *
 */
int sortCarByModel(void* car1, void* car2)
{
    int orden;
    eCar* auxCar1 = NULL;
    eCar* auxCar2 = NULL;

    if(car1 != NULL && car2 != NULL)
    {
        auxCar1 = (eCar*) car1;
        auxCar2 = (eCar*) car2;

        if(strcmp(auxCar1->modelo, auxCar2->modelo) > 0)
        {
            orden = 1;
        }
        else if(strcmp(auxCar1->modelo, auxCar2->modelo) < 0)
        {
            orden = -1;
        }
        else
        {
            orden = 0;
        }
    }
    return orden;
}


/** \brief Ordena las estructuras por anio
 *
 * \param car1 void* puntero a void
 * \param car2 void* puntero a void
 * \return int Retorna el orden
 *
 */
int sortCarByYear(void* car1, void* car2)
{
    int orden;
    eCar* auxCar1 = NULL;
    eCar* auxCar2 = NULL;

    if(car1 != NULL && car2 != NULL)
    {
        auxCar1 = (eCar*) car1;
        auxCar2 = (eCar*) car2;

        if(auxCar1->anio > auxCar2->anio)
        {
            orden = 1;
        }
        else if(auxCar1->anio < auxCar2->anio)
        {
            orden = -1;
        }
        else
        {
            orden = 0;
        }
    }
    return orden;
}
