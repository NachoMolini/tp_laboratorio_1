int controller_loadFromText(char* path , LinkedList* pArrayListCar);
int controller_loadFromBinary(char* path , LinkedList* pArrayListCar);
int controller_addCar(LinkedList* pArrayListCar, int* cantidadAutosP, int contador);
int controller_editCar(LinkedList* pArrayListCar);
int controller_removeCar(LinkedList* pArrayListCar);
int controller_ListCar(LinkedList* pArrayListCar);
int controller_sortCar(LinkedList* pArrayListCar);
int controller_saveAsText(char* path , LinkedList* pArrayListCar);
int controller_saveAsBinary(char* path , LinkedList* pArrayListCar);
int sortCarByBrand(void* car1, void* car2);
int sortCarByModel(void* car1, void* car2);
int sortCarByYear(void* car1, void* car2);

