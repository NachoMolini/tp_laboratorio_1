#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include "LinkedList.h"
#include "Controller.h"
#include "menu.h"

/****************************************************
    Menu:
     1. Cargar los datos de los autos desde el archivo data.csv (modo texto).
     2. Cargar los datos de los autos desde el archivo data.bin (modo binario).
     3. Alta de auto.
     4. Modificar datos de auto.
     5. Baja de auto.
     6. Listar autos.
     7. Ordenar autos.
     8. Guardar los datos de los autos en el archivo data.csv (modo texto).
     9. Guardar los datos de los autos en el archivo data.bin (modo binario).
    10. Salir
*****************************************************/

int main()
{
    char salir = 'n';
    int cantidadAutos;
    int* cantidadAutosP = &cantidadAutos;
    int contador = 1;
    int flag = 0;
    LinkedList* listaAutos = ll_newLinkedList();

    do{
        switch(menu())
        {
            case 1:
                if(!flag)
                {
                    cantidadAutos = controller_loadFromText("data.csv",listaAutos);
                    if(cantidadAutos > 0)
                    {
                        printf("\nSe cargaron en el sistema %d autos.\n\n", cantidadAutos);
                        flag = 1;
                    }
                    else
                    {
                        printf("\nNo se pudo cargar ningun auto.\n\n");
                    }
                }
                else
                {
                    printf("\nYa se cargaron los autos anteriormente.\n\n");
                }
                break;

            case 2:
                if(!flag)
                {
                    cantidadAutos = controller_loadFromBinary("data.bin", listaAutos);
                    if(cantidadAutos > 0)
                    {
                        printf("\nSe cargaron en el sistema %d autos.\n\n", cantidadAutos);
                        flag = 1;
                    }
                    else
                    {
                        printf("\nNo se pudo cargar ningun auto.\n\n");
                    }
                }
                else
                {
                    printf("\nYa se cargaron los autos anteriormente.\n\n");
                }
                break;

            case 3:
                if(controller_addCar(listaAutos, cantidadAutosP, contador))
                {
                    contador++;
                }
                break;

            case 4:
                controller_editCar(listaAutos);
                break;

            case 5:
                controller_removeCar(listaAutos);
                break;

            case 6:
                controller_ListCar(listaAutos);
                break;

            case 7:
                if(controller_sortCar(listaAutos))
                {
                    printf("\nSe han ordenado con exito!\n\n");
                }
                break;

            case 8:
                if(ll_len(listaAutos) > 0)
                {
                    if(controller_saveAsText("data.csv",listaAutos))
                    {
                         printf("\nAutos guardados correctamente en modo texto.\n\n");
                    }
                    else
                    {
                        printf("\nNo se guardaron los autos.\n\n");
                    }
                }
                else
                {
                    printf("\nNo hay autos en el sistema.\n\n");
                }
                break;

            case 9:
                if(ll_len(listaAutos) > 0)
                {
                    if(controller_saveAsBinary("data.bin",listaAutos))
                    {
                         printf("\nAutos guardados correctamente en modo binario.\n\n");
                    }
                    else
                    {
                        printf("\nNo se guardaron los autos.\n\n");
                    }
                }
                else
                {
                    printf("\nNo hay autos en el sistema.\n\n");
                }

                break;

            case 10:
                printf("\nDesea salir?(s/n): ");
                fflush(stdin);
                salir = getche();
                while(salir != 's' && salir != 'n')
                {
                    printf("\nError. Ingrese s o n: ");
                    fflush(stdin);
                    salir = getche();
                }
                printf("\n\n");
                break;


        }

        system("pause");

    }while(salir == 'n');

    return 0;
}
