#include <stdlib.h>
#include <stdio.h>
#include "validaciones.h"

/** \brief Muestra y nos da a elegir una opcion del menu
 *
 * \return int Retorna la opcion elegida
 *
 */
int menu()
{
    char opcionChar[2];
    int opcion;

    system("cls");
    printf("***************************** ABM AUTOS *****************************\n\n");
    printf("1- Cargar los datos de los autos desde el archivo data.csv (modo texto)\n");
    printf("2- Cargar los datos de los autos desde el archivo data.bin (modo binario)\n");
    printf("3- Alta de auto\n");
    printf("4- Modificar datos de auto\n");
    printf("5- Baja de auto\n");
    printf("6- Listar autos\n");
    printf("7- Ordenar autos\n");
    printf("8- Guardar los datos de los autos en el archivo data.csv (modo texto)\n");
    printf("9- Guardar los datos de los autos en el archivo data.bin (modo binario)\n");
    printf("10- Salir\n");
    printf("\nIngrese opcion: ");
    fflush(stdin);
    scanf("%s", opcionChar);
    while(!esNumerico(opcionChar) || atoi(opcionChar) < 0 || atoi(opcionChar) > 10)
    {
        printf("Error. Intente nuevamente: ");
        fflush(stdin);
        scanf("%s", opcionChar);
    }

    opcion = atoi(opcionChar);

    return opcion;
}
