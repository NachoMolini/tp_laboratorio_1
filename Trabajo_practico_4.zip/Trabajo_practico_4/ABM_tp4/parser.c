#include <stdio.h>
#include <stdlib.h>
#include "LinkedList.h"
#include "Car.h"

/** \brief Parsea los datos los datos de los autos desde el archivo data.csv (modo texto).
 *
 * \param path char*
 * \param pArrayListCar LinkedList*
 * \return int Retorna la cantidad de autos que se cargaron
 *
 */
int parser_CarFromText(FILE* pFile , LinkedList* pArrayListCar)
{
    int contador = 0;
    int cantidad = 0;
    char buffer[4][128];
    eCar* auxAuto;

    if(pFile == NULL || pArrayListCar == NULL)
    {
        printf("El archivo no existe o no se pudo conseguir memoria.\n");
        exit(EXIT_FAILURE);
    }

    while(!feof(pFile))
    {
        cantidad = fscanf(pFile, "%[^,],%[^,],%[^,],%[^\n]\n", buffer[0], buffer[1], buffer[2], buffer[3]);
        if(cantidad < 4)
        {
            break;
        }
        else
        {
            auxAuto = car_newParametros(buffer[0], buffer[1], buffer[2], buffer[3]);

            if(auxAuto != NULL && ll_len(pArrayListCar) < 2000
               && ll_add(pArrayListCar, (eCar*)auxAuto) == 0)
            {
                contador++;
            }
        }
    }

    return contador;
}

/** \brief Parsea los datos de los autos desde el archivo data.bin (modo binario).
 *
 * \param path char*
 * \param pArrayListCar LinkedList*
 * \return int Retorna la cantidad de autos que se cargaron
 *
 */
int parser_CarFromBinary(FILE* pFile , LinkedList* pArrayListCar)
{
    int contador = 0;
    int cantidad = 0;
    eCar* auxAuto = NULL;

    if(pFile == NULL || pArrayListCar == NULL)
    {
        printf("El archivo no existe o no se pudo conseguir memoria.\n");
        exit(EXIT_FAILURE);
    }

    while(!feof(pFile))
    {
        auxAuto = car_new();

        if(auxAuto == NULL)
        {
            break;
        }
        cantidad = fread((eCar*)auxAuto, sizeof(eCar), 1, pFile);
        if(cantidad  < 1)
        {
            break;
        }
        else if(ll_len(pArrayListCar) < 2000 && !ll_add(pArrayListCar, (eCar*)auxAuto))
        {
            contador++;
        }
    }
    return contador;
}
