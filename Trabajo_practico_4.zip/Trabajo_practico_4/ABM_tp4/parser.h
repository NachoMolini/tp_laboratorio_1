int parser_CarFromText(FILE* pFile , LinkedList* pArrayListCar);
int parser_CarFromBinary(FILE* pFile , LinkedList* pArrayListCar);
