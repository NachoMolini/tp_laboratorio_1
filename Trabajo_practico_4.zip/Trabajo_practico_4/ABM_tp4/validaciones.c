#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

/**
 * \brief Verifica si el valor recibido es num�rico
 * \param str Array con la cadena a ser analizada
 * \return 1 si es n�merico y 0 si no lo es
 *
 */
int esNumerico(char str[])
{
   int i = 0;

   while(str[i] != '\0')
   {
       if(str[i] < '0' || str[i] > '9')
       {
           return 0;
       }
       i++;
   }
   return 1;
}


/**
 * \brief Verifica si el valor recibido es num�rico aceptando flotantes
 * \param str Array con la cadena a ser analizada
 * \return 1 si es n�merico y 0 si no lo es
 *
 */
int esNumericoFlotante(char str[])
{
   int i = 0;
   int cantidadPuntos = 0;

   while(str[i] != '\0')
   {
       if (str[i] == '.' && cantidadPuntos == 0)
       {
           cantidadPuntos++;
           i++;
           continue;
       }
       if(str[i] < '0' || str[i] > '9')
       {
           return 0;
       }
       i++;
   }
   return 1;
}

/**
 * \brief Verifica si el valor recibido contiene solo letras
 * \param str Array con la cadena a ser analizada
 * \return 1 si contiene solo ' ' y letras y 0 si no lo es
 *
 */
int esSoloLetras(char str[])
{
   int i=0;

   while(str[i] != '\0')
   {
       if((str[i] != ' ') && (str[i] < 'a' || str[i] > 'z') && (str[i] < 'A' || str[i] > 'Z'))
       {
           return 0;
       }
       i++;
   }
   return 1;
}


/**
 * \brief Verifica si el valor recibido contiene solo letras y guiones
 * \param str Array con la cadena a ser analizada
 * \return 1 si contiene solo ' ', letras y guiones, y 0 si no lo es
 *
 */
int esSoloLetrasYGuiones(char str[])
{
   int i=0;
   while(str[i] != '\0')
   {
       if((str[i] != ' ') && (str[i] < 'a' || str[i] > 'z') && (str[i] < 'A' || str[i] > 'Z') && str[i] != '-')
           return 0;
       i++;
   }
   return 1;
}

/**
 * \brief Verifica si el valor recibido contiene solo letras y n�meros
 * \param str Array con la cadena a ser analizada
 * \return 1 si contiene solo espacio o letras y n�meros, y 0 si no lo es
 *
 */
int esAlfaNumerico(char str[])
{
   int i=0;
   while(str[i] != '\0')
   {
       if((str[i] != ' ') && (str[i] < 'a' || str[i] > 'z') && (str[i] < 'A' || str[i] > 'Z') && (str[i] < '0' || str[i] > '9'))
           return 0;
       i++;
   }
   return 1;
}


/**
 * \brief Verifica si el valor recibido contiene solo letras, n�meros y guiones
 * \param str Array con la cadena a ser analizada
 * \return 1 si contiene solo espacio o letras, n�meros y guiones, y 0 si no lo es
 *
 */
int esAlfaNumericoYGuiones(char str[])
{
   int i=0;
   while(str[i] != '\0')
   {
       if((str[i] != ' ') && (str[i] < 'a' || str[i] > 'z') && (str[i] < 'A' || str[i] > 'Z') && (str[i] < '0' || str[i] > '9') && str[i] != '-')
           return 0;
       i++;
   }
   return 1;
}


/**
 * \brief Pasa la primera letra a mayuscula
 * \param str Array con la cadena a ser analizada
 *
 */
void primeraLetraMayus(char str[])
{
    int i = 0;

    str[0] = toupper(str[0]);
    while(str[i] != '\0')
    {
        if(str[i] == ' ' || str[i] == '-')
        {
            str[i+1] = toupper(str[i+1]);
        }
        i++;
    }
}


