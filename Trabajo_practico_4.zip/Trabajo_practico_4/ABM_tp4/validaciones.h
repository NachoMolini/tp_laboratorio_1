int esNumerico(char str[]);
int esNumericoFlotante(char str[]);
int esSoloLetras(char str[]);
int esSoloLetrasYGuiones(char str[]);
int esAlfaNumerico(char str[]);
int esAlfaNumericoYGuiones(char str[]);
void primeraLetraMayus(char str[]);
